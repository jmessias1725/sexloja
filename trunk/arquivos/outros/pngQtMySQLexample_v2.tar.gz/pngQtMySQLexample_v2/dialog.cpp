#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent), ui(new Ui::Dialog)
{
    ui->setupUi(this);
    ui->fileNameLabel->setText("pessoa.png");
    model = new QSqlTableModel(this);
    setModel();
    setView();
    connect(model, SIGNAL(beforeInsert(QSqlRecord &)), this, SLOT(beforeInsertFoto(QSqlRecord &)));
    connect(view, SIGNAL(clicked(QModelIndex)), this, SLOT(getCurrentRecordClicked(QModelIndex)));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::loadPngImage(){
    fileName = QFileDialog::getOpenFileName(this,
                                     "Seleccione o ficheiro de origem",
                                     ".",
                                     "Ficheiro de texto (*.png)");
    ui->foto->setPixmap(QPixmap(fileName));
    QFileInfo fi(fileName);
    ui->fileNameLabel->setText(fi.fileName());
    QApplication::processEvents();
    this->adjustSize();
}

void Dialog::setModel()
{
    model->setTable("photo");
    model->setHeaderData(photo_id, Qt::Horizontal, tr("ID"));
    model->setHeaderData(photo_name, Qt::Horizontal, trUtf8("Filename"));
    model->setHeaderData(photo_image, Qt::Horizontal, trUtf8("Image"));
    model->select();
}

void Dialog::setView()
{
    view = ui->tableView;
    view->setModel(model);
    view->setColumnHidden(photo_image, true);
    view->horizontalHeader()->setStretchLastSection(true);
    view->setSelectionMode(QAbstractItemView::SingleSelection);
    view->setSelectionBehavior(QAbstractItemView::SelectRows);
}

void Dialog::beforeInsertFoto(QSqlRecord &record)
{
    //prepare data dor id - generated key
    record.setValue("id", generateId("photo"));
    //prepare data for name - get it form the label in the ui
    record.setValue("name", ui->fileNameLabel->text());
    //prepare data for image - get it from the label in the ui
    QImage currentImage = ui->foto->pixmap()->toImage();
    QByteArray bytes;
    QBuffer buffer(&bytes);
    buffer.open(QIODevice::WriteOnly);
    currentImage.save(&buffer, "PNG");
    record.setValue("image", bytes);
}

void Dialog::insertNewRecord()
{
    int row = model->rowCount();
    model->insertRow(row);
    model->submitAll();
}

void Dialog::getCurrentRecordClicked(QModelIndex index)
{

    //get image filename
    ui->fileNameLabel->setText(model->data(model->index(index.row(), photo_name),0).toString());
    //get image
    QVariant currentImage = model->data(model->index(index.row(), photo_image),0);
    QByteArray bytes = currentImage.toByteArray();
    QImage image;
    image.loadFromData(bytes);
    ui->foto->setPixmap(QPixmap::fromImage(image));
    QApplication::processEvents();
    this->adjustSize();
}
void Dialog::deleteSelectedRecord()
{
    view->setFocus();
    QModelIndex index = view->currentIndex();
    if(!index.isValid())
        return;
    model->removeRow(view->currentIndex().row());
}
