#include <QtGui/QInputDialog>
#include <QtGui/QTextCharFormat>
#include "calendar.h"

Calendar::Calendar( QWidget *parent, Qt::WindowFlags f ) :
    QDialog( parent, f )
{
    setupUi( this );

    // connections
    connect( pushButtonToday, SIGNAL( clicked() ), this, SLOT( todayClicked()));
    connect( calendarWidget, SIGNAL( activated( const QDate & )),
            this, SLOT( addNote( const QDate & )));
}

void Calendar::todayClicked()
{
    calendarWidget->setSelectedDate( QDate::currentDate() );
    dateEdit->setDate( QDate::currentDate() );
}

void Calendar::addNote( const QDate &date )
{
    QString memo = QInputDialog::getText( this,
            "Memo", "Description:" );

    if( !memo.isEmpty() ){
        QBrush brush;
        brush.setColor( Qt::green );
        QTextCharFormat cf = calendarWidget->dateTextFormat( date );
        cf.setBackground( brush );
        calendarWidget->setDateTextFormat( date, cf );
    }
}
