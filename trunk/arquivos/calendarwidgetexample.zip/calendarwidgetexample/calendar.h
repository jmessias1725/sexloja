#ifndef CALENDAR_H
#define CALENDAR_H

#include "ui_calendar.h"

class Calendar : public QDialog, Ui_CalendarDialog
{
    Q_OBJECT
    public:
        Calendar( QWidget * parent = 0, Qt::WindowFlags f = 0 );

    private slots:
        void todayClicked();
        void addNote( const QDate & );
};

#endif // CALENDAR_H
